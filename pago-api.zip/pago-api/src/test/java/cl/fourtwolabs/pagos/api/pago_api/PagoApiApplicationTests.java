package cl.fourtwolabs.pagos.api.pago_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PagoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
