package cl.demo.camel.procesos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamelDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
