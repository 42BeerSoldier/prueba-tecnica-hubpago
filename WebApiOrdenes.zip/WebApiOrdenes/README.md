# WebApiOrdenes

Este proyecto es una API web desarrollada en ASP.NET Framework 4.6.2 para la gesti�n de �rdenes. Proporciona endpoints para crear, consultar y administrar �rdenes mediante controladores RESTful.

## Caracter�sticas

- API REST para operaciones CRUD de �rdenes.
- Arquitectura basada en controladores y repositorios.
- Uso de modelos y DTOs para la transferencia de datos.
- Ejemplo de integraci�n con servicios y l�gica de negocio.

## Estructura del proyecto

- **Controllers**: L�gica de los endpoints (`OrdenesController`, `ValuesController`, `HomeController`).
- **Models**: Definici�n de entidades y DTOs (`Orden`, `Dtos`).
- **Services**: Acceso a datos y l�gica de negocio (`OrdenRepository`).

## Requisitos

- .NET Framework 4.6.2
- Visual Studio 2022

## Ejecuci�n

1. Clona el repositorio.
2. Abre la soluci�n en Visual Studio 2022.
3. Restaura los paquetes NuGet si es necesario.
4. Ejecuta el proyecto (`F5`).

## Endpoints principales

- `GET /api/ordenes` - Lista todas las �rdenes.
- `POST /api/ordenes` - Crea una nueva orden.
- `GET /api/ordenes/{id}` - Consulta una orden por ID.
- `PUT /api/ordenes/{id}` - Actualiza una orden existente.
- `DELETE /api/ordenes/{id}` - Elimina una orden.

## Licencia

Este proyecto se distribuye bajo la licencia MIT.