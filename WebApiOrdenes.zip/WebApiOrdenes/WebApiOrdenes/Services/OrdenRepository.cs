﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Web;
using System.Xml.Serialization;
using WebApiOrdenes.Models;

namespace WebApiOrdenes.Services
{
    public sealed class OrdenRepository
    {
        private static readonly Lazy<OrdenRepository> _instance =
            new Lazy<OrdenRepository>(() => new OrdenRepository(), LazyThreadSafetyMode.ExecutionAndPublication);

        public static OrdenRepository Instance => _instance.Value;

        private readonly List<Orden> _ordenes = new List<Orden>();
        private readonly object _lock = new object();
        private readonly string _jsonPath;
        private readonly string _xmlPath;

        private OrdenRepository()
        {
            var ctx = HttpContext.Current;
            _jsonPath = ctx.Server.MapPath("~/App_Data/ordenes.json");
            _xmlPath = ctx.Server.MapPath("~/App_Data/ordenes.xml");

            Directory.CreateDirectory(Path.GetDirectoryName(_jsonPath));
            CargarDesdeDiscoSiExiste();
        }

        public IEnumerable<Orden> GetAll()
        {
            lock (_lock)
            {
                return new List<Orden>(_ordenes);
            }
        }

        public Orden Add(Orden o)
        {
            lock (_lock)
            {
                _ordenes.Add(o);
                GuardarADisco();
                return o;
            }
        }

        private void CargarDesdeDiscoSiExiste()
        {
            try
            {
                if (File.Exists(_jsonPath))
                {
                    var json = File.ReadAllText(_jsonPath);
                    var list = JsonConvert.DeserializeObject<List<Orden>>(json) ?? new List<Orden>();
                    _ordenes.Clear();
                    _ordenes.AddRange(list);
                }
            }
            catch
            {
                // Si falla la carga, se arranca vacío
            }
        }

        private void GuardarADisco()
        {
            // JSON
            var json = JsonConvert.SerializeObject(_ordenes, Formatting.Indented);
            File.WriteAllText(_jsonPath, json);

            // XML
            var serializer = new XmlSerializer(typeof(List<Orden>));
            using (var fs = File.Create(_xmlPath))
            {
                serializer.Serialize(fs, _ordenes);
            }
        }
    }
}