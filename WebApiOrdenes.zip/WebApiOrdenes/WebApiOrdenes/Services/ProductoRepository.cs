﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Web;
using System.Xml.Serialization;
using WebApiOrdenes.Models;

namespace WebApiOrdenes.Services
{
    public sealed class ProductoRepository
    {
        private static readonly Lazy<ProductoRepository> _instance =
            new Lazy<ProductoRepository>(() => new ProductoRepository(), LazyThreadSafetyMode.ExecutionAndPublication);

        public static ProductoRepository Instance => _instance.Value;

        private readonly List<Producto> _productos = new List<Producto>();
        private readonly object _lock = new object();
        private readonly string _jsonPath;
        private readonly string _xmlPath;

        private ProductoRepository()
        {
            var ctx = HttpContext.Current;
            _jsonPath = ctx.Server.MapPath("~/App_Data/productos.json");
            _xmlPath = ctx.Server.MapPath("~/App_Data/productos.xml");

            Directory.CreateDirectory(Path.GetDirectoryName(_jsonPath));
            CargarDesdeDiscoSiExiste();
        }

        public IEnumerable<Producto> GetAll()
        {
            lock (_lock) { return new List<Producto>(_productos); }
        }

        public Producto Add(Producto p)
        {
            lock (_lock)
            {
                _productos.Add(p);
                GuardarADisco();
                return p;
            }
        }

        private void CargarDesdeDiscoSiExiste()
        {
            try
            {
                if (File.Exists(_jsonPath))
                {
                    var json = File.ReadAllText(_jsonPath);
                    var list = JsonConvert.DeserializeObject<List<Producto>>(json) ?? new List<Producto>();
                    _productos.Clear();
                    _productos.AddRange(list);
                }
            }
            catch { /* arranca vacío si falla */ }
        }

        private void GuardarADisco()
        {
            var json = JsonConvert.SerializeObject(_productos, Formatting.Indented);
            File.WriteAllText(_jsonPath, json);

            var serializer = new XmlSerializer(typeof(List<Producto>));
            using (var fs = File.Create(_xmlPath))
            {
                serializer.Serialize(fs, _productos);
            }
        }
    }
}
