﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace WebApiOrdenes.Models
{
    public class CrearOrdenDto
    {
        [Required, StringLength(120)]
        public string Cliente { get; set; }

        [Required]
        public DateTime Fecha { get; set; }

        [Required]
        public List<CrearOrdenItemDto> Items { get; set; }
    }

    public class CrearOrdenItemDto
    {
        [Required, StringLength(120)]
        public string Producto { get; set; }

        [Range(1, int.MaxValue)]
        public int Cantidad { get; set; }

        // Cambiado "0.0" -> "0"
        [Range(typeof(decimal), "0", "79228162514264337593543950335", ErrorMessage = "PrecioUnitario debe ser >= 0")]
        public decimal PrecioUnitario { get; set; }
    }
}