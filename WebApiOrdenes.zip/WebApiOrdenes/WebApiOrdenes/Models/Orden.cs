﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace WebApiOrdenes.Models
{
    public class Orden
    {
        public Guid Id { get; set; }

        [Required, StringLength(120)]
        public string Cliente { get; set; }

        [Required]
        public DateTime Fecha { get; set; }

        [Required, MinLength(1, ErrorMessage = "La orden debe tener al menos un ítem.")]
        public List<OrdenItem> Items { get; set; } = new List<OrdenItem>();

        public decimal Total { get; set; }
    }

    public class OrdenItem
    {
        [Required, StringLength(120)]
        public string Producto { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Cantidad debe ser >= 1")]
        public int Cantidad { get; set; }

  
        public decimal PrecioUnitario { get; set; }


        public decimal Subtotal => Cantidad * PrecioUnitario;
    }
}