﻿using System;
using System.ComponentModel.DataAnnotations;

namespace WebApiOrdenes.Models
{
    public class Producto
    {
        public Guid Id { get; set; }

        [Required, StringLength(120)]
        public string Nombre { get; set; }

        [StringLength(300)]
        public string Descripcion { get; set; }

        [Range(typeof(decimal), "0", "79228162514264337593543950335",
            ErrorMessage = "Precio debe ser >= 0")]
        public decimal Precio { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Stock debe ser >= 0")]
        public int Stock { get; set; }
    }

    // DTO de creación/edición (sin Id)
    public class CrearProductoDto
    {
        [Required, StringLength(120)]
        public string Nombre { get; set; }

        [StringLength(300)]
        public string Descripcion { get; set; }

        [Range(typeof(decimal), "0", "79228162514264337593543950335")]
        public decimal Precio { get; set; }

        [Range(0, int.MaxValue)]
        public int Stock { get; set; }
    }
}
