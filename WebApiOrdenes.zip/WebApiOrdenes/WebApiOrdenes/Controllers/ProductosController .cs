﻿using System;
using System.Linq;
using System.Web.Http;
using WebApiOrdenes.Models;
using WebApiOrdenes.Services;

namespace WebApiOrdenes.Controllers
{
    [RoutePrefix("productos")] // => /productos
    public class ProductosController : ApiController
    {
        // GET /productos
        [HttpGet]
        [Route("")]
        public IHttpActionResult Get()
        {
            var lista = ProductoRepository.Instance.GetAll();
            return Ok(lista);
        }

        // POST /productos
        [HttpPost]
        [Route("")]
        public IHttpActionResult Post([FromBody] CrearProductoDto dto)
        {
            if (dto == null) return BadRequest("Cuerpo vacío.");

            if (!ModelState.IsValid)
            {
                var errores = string.Join(" | ",
                    ModelState.Where(k => k.Value.Errors.Count > 0)
                              .Select(k => $"{k.Key}: {string.Join(", ", k.Value.Errors.Select(e => e.ErrorMessage ?? e.Exception?.Message))}"));
                return BadRequest(errores);
            }

            var prod = new Producto
            {
                Id = Guid.NewGuid(),
                Nombre = dto.Nombre,
                Descripcion = dto.Descripcion,
                Precio = dto.Precio,
                Stock = dto.Stock
            };

            var creado = ProductoRepository.Instance.Add(prod);
            var location = new Uri(Request.RequestUri, "/productos");
            return Created(location, creado);
        }
    }
}
