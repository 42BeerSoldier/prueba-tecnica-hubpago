﻿using System;
using System.Linq;
using System.Web.Http;
using WebApiOrdenes.Models;
using WebApiOrdenes.Services;

namespace WebApiOrdenes.Controllers
{
    [RoutePrefix("ordenes")] // Expondrá /ordenes (no /api/ordenes)
    public class OrdenesController : ApiController
    {
        // GET /ordenes
        [HttpGet]
        [Route("")]
        public IHttpActionResult Get()
        {
            var lista = OrdenRepository.Instance.GetAll();
            return Ok(lista);
        }

        // POST /ordenes
        [HttpPost]
        [Route("")]
        public IHttpActionResult Post([FromBody] CrearOrdenDto dto)
        {
            if (dto == null)
                return BadRequest("Cuerpo de la solicitud vacío.");

            if (!ModelState.IsValid)
            {
                var errores = string.Join(" | ",
                    ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                return BadRequest(errores);
            }

            var orden = new Orden
            {
                Id = Guid.NewGuid(),
                Cliente = dto.Cliente,
                Fecha = dto.Fecha,
                Items = dto.Items.Select(i => new OrdenItem
                {
                    Producto = i.Producto,
                    Cantidad = i.Cantidad,
                    PrecioUnitario = i.PrecioUnitario
                }).ToList()
            };

            orden.Total = orden.Items.Sum(x => x.Cantidad * x.PrecioUnitario);

            var creada = OrdenRepository.Instance.Add(orden);

            // 201 Created con Location: /ordenes
            var location = new Uri(Request.RequestUri, "/ordenes");
            return Created(location, creada);
        }
    }
}

