import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Producto } from '../models/producto';

@Injectable({ providedIn: 'root' })
export class ProductosService {
  private base = '/productos'; // proxy a https://localhost:44322/productos
  constructor(private http: HttpClient) {}
  listar(): Observable<Producto[]> { return this.http.get<Producto[]>(this.base); }
  crear(p: Producto): Observable<Producto> { return this.http.post<Producto>(this.base, p); }
}
