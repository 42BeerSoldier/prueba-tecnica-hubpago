export interface Producto {
  id?: number;
  Nombre: string;
  Descripcion: string;
  Precio: number;
  Stock: number;
}
