import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Producto } from './models/producto';
import { FormBuilder, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { ProductosService } from './services/prodcutos.service';
import { finalize, take } from 'rxjs';
import { NgIf, NgFor } from '@angular/common';

@Component({
  standalone: true,
  imports: [RouterOutlet,ReactiveFormsModule, FormsModule, NgIf, NgFor],
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {

  productos: Producto[] = [];
  cargando = false;
  creando = false;
  ok: string | null = null;
  error: string | null = null;
  title = 'OrdenesWebApp';

  form = this.fb.group({
    nombre: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(120)]],
    descripcion: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(500)]],
    precio: [0, [Validators.required, Validators.min(0)]],
    stock: [0, [Validators.required, Validators.min(0)]],
  });



  constructor(private fb: FormBuilder, private api: ProductosService) { }

  ngOnInit(): void { this.cargar(); }

  cargar(): void {
    this.cargando = true; this.error = null;
    this.api.listar().subscribe({
      next: data => { this.productos = data ?? []; this.cargando = false; },
      error: err => { this.error = 'No se pudieron cargar los productos'; this.cargando = false; console.error(err); }
    });
  }

  submit(): void {
    if (this.creando) return;              // evita doble click
    this.ok = null; this.error = null;
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }

    const { nombre, descripcion, precio, stock } = this.form.getRawValue();
    const payload: Producto = {
      Nombre: nombre!.trim(),
      Descripcion: descripcion!.trim(),
      Precio: Number(precio),
      Stock: Number(stock)
    };

    this.creando = true;
    this.api.crear(payload).pipe(
      take(1),
      finalize(() => this.creando = false)
    ).subscribe({
      next: () => {
        this.ok = 'Producto creado';
        this.form.reset({ nombre: '', descripcion: '', precio: 0, stock: 0 });
        this.form.markAsPristine();
        this.form.markAsUntouched();
        this.cargar();
      },
      error: (err) => {
        this.error = err?.error?.message ?? 'No se pudo crear el producto';
        console.error(err);
      }
    });
  }
}
